This is a fix for rigacar for Blender 4.2

I am NOT the creator of the add-on. I do not take any guarantees for this. Use on own risk.
